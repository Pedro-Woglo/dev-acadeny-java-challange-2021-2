package br.com.cm.workshop.apicrud.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum StatusEnum {
    
    PENDENTE("Pendente"),
    EM_PROCESSAMENTO("Em_processamento"),
    APROVADA("Aprovada"),
    COM_ERRO("Com_erro"),
    CANCELADA("Cancelada");

    private final String status;
}
