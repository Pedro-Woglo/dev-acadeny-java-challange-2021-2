package br.com.cm.workshop.apicrud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cm.workshop.apicrud.model.Status;
import br.com.cm.workshop.apicrud.service.StatusService;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Status")
@RestController
@RequestMapping(path = "/api/v1/notas-fiscais")
public class StatusController {

    @Autowired
    private StatusService service;

    @PatchMapping("/{id}/status")
    public Status alteraStatus(@PathVariable Long id, @RequestBody Status status) {
        return service.alteraStatus(id, status);
    }
}