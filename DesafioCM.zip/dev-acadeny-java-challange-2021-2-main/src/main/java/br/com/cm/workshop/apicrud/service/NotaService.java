package br.com.cm.workshop.apicrud.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;
import br.com.cm.workshop.apicrud.model.Item;
import br.com.cm.workshop.apicrud.model.NotaFiscal;
import br.com.cm.workshop.apicrud.repository.NotaRepository;

@Service
public class NotaService {

    @Autowired
    private NotaRepository repository;

    public List<NotaFiscal> listaTodos(){
        return repository.findAll();
    }

    public NotaFiscal criarNotaFiscal(NotaFiscal nota){
        double soma = 0;
        for(Item item : nota.getItens()){
            item.setValorTotal(item.getPrecoUnitario() * item.getQuantidade());
            soma += item.getValorTotal();
        }
        nota.setValorTotalProdutos(soma);
        nota.setValorTotal(nota.getValorTotalProdutos() + nota.getFrete());
        return repository.saveAndFlush(nota);
    }

    public Optional<NotaFiscal> apagaNotaFiscal(Long id) {
        return repository.findById(id);
    }

    public NotaFiscal atualizaNotaFiscal(Long id, NotaFiscal nota){
        if(repository.existsById(id)) {
            if(id.equals(nota.getId())) {
                return repository.saveAndFlush(nota);
            }
            else
                throw new UnsupportedOperationException("Id inserido não corresponde ao id da nota");
        } else
            throw new EntityNotFoundException("Nota fiscal não encontrada");
    }
}
