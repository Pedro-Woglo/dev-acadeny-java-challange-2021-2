package br.com.cm.workshop.apicrud.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cm.workshop.apicrud.model.Status;

@Repository
public interface StatusRepository extends JpaRepository<Status, Long> {

    Status alteraStatus(Long id, Status status);
    
}
