package br.com.cm.workshop.apicrud.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NotaFiscal implements Serializable {
    
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue
    private Long id;
    
    //@NotEmpty(message = "nome é obrigatório")
    private String nomeCliente;
    
    //@Size(max = 100, min = 5, message = "o endereço deve ter tamanho minimo de 5 de tamanho máximo de 100 caracteres")
    private String endereco;

    private int telefone;

    //@Enumerated(EnumType.STRING)
    //private NotaStatus status;

    private double valorTotalProdutos;

    private double frete;

    private double valorTotal;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Item> itens;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Status> status;
    
}
