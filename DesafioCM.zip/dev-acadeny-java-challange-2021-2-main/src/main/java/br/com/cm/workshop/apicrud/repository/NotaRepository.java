package br.com.cm.workshop.apicrud.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cm.workshop.apicrud.model.NotaFiscal;

@Repository
public interface NotaRepository extends JpaRepository<NotaFiscal, Long> {
    
}
