package br.com.cm.workshop.apicrud.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cm.workshop.apicrud.model.Item;

@Repository
public interface ItensRepository extends JpaRepository<Item, Long> {

}
